package com.example.usingactivities;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    TextView txtBien;
    ImageView imgFoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        txtBien = findViewById(R.id.txtBien);
        txtBien.setText("Bienvenido " + getIntent().getStringExtra("username"));

        imgFoto = findViewById(R.id.imgFoto);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.opt1:
                //Toast.makeText(this, "Elegiste opcion 1", Toast.LENGTH_SHORT).show();
                navegar();
                break;
            case R.id.opt2:
                //Toast.makeText(this, "Elegiste opcion 2", Toast.LENGTH_SHORT).show();
                llamada();
                break;
            case R.id.opt3:
                Toast.makeText(this, "Elegiste opcion 3", Toast.LENGTH_SHORT).show();

                break;
            case R.id.opt4:
                Toast.makeText(this, "Elegiste opcion 4", Toast.LENGTH_SHORT).show();
                foto();
                break;
            case R.id.opt5:
                Toast.makeText(this, "Elegiste opcion 5", Toast.LENGTH_SHORT).show();

                break;
            case R.id.opt6:
                //Toast.makeText(this, "Elegiste opcion 6", Toast.LENGTH_SHORT).show();
                salir();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void navegar(){
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse("https://sii.itcelaya.edu.mx/sii/index.php?r=cruge/ui/login"));
        startActivity(i);
    }

    private void llamada(){
        Intent i = new Intent(Intent.ACTION_DIAL);
        startActivity(i);
    }

    private void salir(){
        AlertDialog.Builder a = new AlertDialog.Builder(this);
        a.setTitle("Salir");
        a.setMessage("¿Seguro de salir?");
        a.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        a.setNegativeButton("Cancelar",null);
        a.show();
    }

    private void foto(){
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(i,0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            Bitmap bitmap = (Bitmap) data.getExtras().get("data");
            imgFoto.setImageBitmap(bitmap);
        }
    }
}
