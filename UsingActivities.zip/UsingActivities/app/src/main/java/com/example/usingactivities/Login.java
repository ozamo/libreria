package com.example.usingactivities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    Button btnCancel, btnAccept;
    EditText edtUser, edtPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAccept = findViewById(R.id.btnAccept);
        btnCancel = findViewById(R.id.btnCancel);
        edtPass = findViewById(R.id.edtPass);
        edtUser = findViewById(R.id.edtUser);

        btnAccept.setOnClickListener(listen);
        btnCancel.setOnClickListener(listen);
    }

    View.OnClickListener listen = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v == btnAccept){
                validateCredentials();
            }else if(v == btnCancel){
                finish();
            }
        }
    };

    void validateCredentials(){
        edtUser.setText("admin");
        edtPass.setText("123");
        if(edtUser.getText().toString().equals("admin")&&edtPass.getText().toString().equals("123")){
            //Toast.makeText(this, "User correct", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, HomeActivity.class);
            i.putExtra("username",edtUser.getText().toString());
            startActivity(i);
        }
        else{
            Toast.makeText(this, "User wrong", Toast.LENGTH_LONG).show();
        }
    }
}
