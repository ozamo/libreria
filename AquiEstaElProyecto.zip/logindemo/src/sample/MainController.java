package sample;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.Optional;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    public static final String DEST5 = "results/chapter01/empbydept.pdf";

    @FXML
    MenuItem menSal,menDep,menMa;
    @FXML
    Button btnSave,btnDelete,btnNew, btndepartamentos,bntcambio,btnDeptEmp;
    @FXML
    TextField txtEmpNo,txtFirstName,txtLastName;
    @FXML
    DatePicker dpBirthDate,dpHireDate;
    @FXML
    ComboBox<String> cmbGender;
    @FXML
    TableView<Employee> tableEmployee;



    EmployeeDAO employeeDAO=new EmployeeDAO(MySQL.getConnection());
    private boolean insertMode=false;
    private boolean updateMode=false;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cmbGender.getItems().addAll("M","F");
        TableColumn col1=new TableColumn("Emp No");
        TableColumn col2=new TableColumn("First Name");
        TableColumn col3=new TableColumn("Last Name");
        TableColumn col4=new TableColumn("Gender");

        col1.setCellValueFactory(new PropertyValueFactory<>("emp_no"));//relacionamos la columna de la conexion
        col2.setCellValueFactory(new PropertyValueFactory<>("first_name"));
        col3.setCellValueFactory(new PropertyValueFactory<>("last_name"));
        col4.setCellValueFactory(new PropertyValueFactory<>("gender"));

        tableEmployee.getColumns().addAll(col1,col2,col3,col4);

        ObservableList<Employee> employeeList=employeeDAO.fetchAll();
        tableEmployee.setItems(employeeList);

        btnSave.setOnAction(handlerSaveEmployee);

        menSal.setOnAction(handlerReport);
        btnNew.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                clearForm();
                insertMode=true;
                updateMode=false;
            }
        });

        tableEmployee.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(event.getClickCount()==2){
                    updateMode=true;
                    insertMode=false;
                    Employee employee=tableEmployee.getSelectionModel().getSelectedItem();

                    txtEmpNo.setText(String.valueOf(employee.getEmp_no()));
                    dpBirthDate.setValue(employee.getBirth_date().toLocalDate());
                    dpHireDate.setValue(employee.getHire_date().toLocalDate());
                    txtFirstName.setText(employee.getFirst_name());
                    txtLastName.setText(employee.getLast_name());
                    cmbGender.setValue(String.valueOf(employee.getGender()));

                }
            }
        });

        btnDelete.setOnAction(handlerDeleteEmployee);

//___ Botones de Cambio de Stage________________________________________________________________________________________

        btnDeptEmp.setOnAction(CambioDeptEmp);

        btndepartamentos.setOnAction(CambioDepartamentos);
//______________________________________________________________________________________________________________________


    }
/***********************************************************************************************************************
Apartir de aqui se encuentran los metodos de los botones y los evewntos

***********************************************************************************************************************/

//Accion reorte
        EventHandler<ActionEvent> handlerReport=new EventHandler<ActionEvent>() {
    @Override
    public void handle(ActionEvent event) {
        File file = new File(DEST5);
        file.getParentFile().mkdirs();
        try {
            EmployeeDAO emp = new EmployeeDAO(MySQL.getConnection());
            new EmpByDept().createPdf(DEST5,emp.findAll());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
};

//__ Cambios entre Stage _______________________________________________________________________________________________


    //Accion de cambio de Stage a Departamentos

    EventHandler<ActionEvent> CambioDepartamentos = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            try{
                Parent root = FXMLLoader.load(getClass().getResource("MenuDepartamentos.fxml"));
                Stage stage=new Stage();
                stage.setTitle("Departamentos");
                Scene scene=new Scene(root);
                scene.getStylesheets().add("org/kordamp/bootstrapfx/bootstrapfx.css");
                stage.setScene(scene);
                stage.setMaximized(false);
                stage.show();
                ((Stage)(btndepartamentos.getScene().getWindow())).hide();

            }
            catch (IOException e){
                System.out.println(e.getMessage());
            }

        }
    };


    //Accion de cambio de Stage a Departamentos Empleados

    EventHandler<ActionEvent> CambioDeptEmp = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            try{
                Parent root = FXMLLoader.load(getClass().getResource("MenuDepartamentoEmpleados.fxml"));
                Stage stage=new Stage();
                stage.setTitle("Departamentos Empleados");
                Scene scene=new Scene(root);
                scene.getStylesheets().add("org/kordamp/bootstrapfx/bootstrapfx.css");
                stage.setScene(scene);
                stage.setMaximized(false);
                stage.show();
                ((Stage)(btndepartamentos.getScene().getWindow())).hide();

            }
            catch (IOException e){
                System.out.println(e.getMessage());
            }

        }
    };


//______________________________________________________________________________________________________________________

    // accion de eliminacion de registro

    EventHandler<ActionEvent> handlerDeleteEmployee=new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("DELETE Confirmation");
            alert.setContentText("Are you sure you want to DELETE this employee?");
            Optional<ButtonType> result = alert.showAndWait();
            if(result.get()==ButtonType.OK) {
                Employee employee=tableEmployee.getSelectionModel().getSelectedItem();
                employeeDAO.delete(employee.getEmp_no());
                clearForm();
                reloadEmployeeList();
            }
            else{
                alert.close();
            }
        }
    };


    // Accion de cambio entre Actualizar y registrar

    EventHandler<ActionEvent> handlerSaveEmployee= new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            if(insertMode){
                insertEmployee();
            }else if(updateMode){
                updateEmployee();
            }
        }
    };



    private void insertEmployee(){
        Employee employee=new Employee(
                Integer.valueOf(txtEmpNo.getText()),
                Date.valueOf(dpBirthDate.getValue()),
                txtFirstName.getText(),
                txtLastName.getText(),
                cmbGender.getSelectionModel().getSelectedItem().charAt(0),
                Date.valueOf(dpHireDate.getValue())

        );
        if(employeeDAO.insert(employee)){
            reloadEmployeeList();
            clearForm();
        }
    }

    private void updateEmployee(){
        Employee employee=new Employee(
                Integer.valueOf(txtEmpNo.getText()),
                Date.valueOf(dpBirthDate.getValue()),
                txtFirstName.getText(),
                txtLastName.getText(),
                cmbGender.getSelectionModel().getSelectedItem().charAt(0),
                Date.valueOf(dpHireDate.getValue())

        );
        if(employeeDAO.update(employee)){
            reloadEmployeeList();
            clearForm();
        }
    }

    private void reloadEmployeeList(){
        tableEmployee.getItems().clear();
        tableEmployee.setItems(employeeDAO.fetchAll());
    }

    private void clearForm(){
        txtEmpNo.setText("");
        txtFirstName.setText("");
        txtLastName.setText("");
        dpBirthDate.setValue(null);
        dpHireDate.setValue(null);
        cmbGender.valueProperty().set(null);
    }
}
