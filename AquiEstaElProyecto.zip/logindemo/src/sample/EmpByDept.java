package sample;

/*
 * This example is part of the iText 7 tutorial.
 */

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.test.annotations.WrapToTest;

import java.io.IOException;
import java.util.List;

/**
 * Simple table example.
 */
@WrapToTest
public class EmpByDept {
    public static final String DATA = "src/resources/united_states.csv";

    /*public static final String DEST = "results/chapter01/united_states.pdf";

    public static void main(String args[]) throws IOException {
        File file = new File(DEST);
        file.getParentFile().mkdirs();
        new C01E04_UnitedStates().createPdf(DEST);
    }*/

    public void createPdf(String dest, List<Employee> employees) throws IOException {
        //Initialize PDF writer
        PdfWriter writer = new PdfWriter(dest);

        //Initialize PDF document
        PdfDocument pdf = new PdfDocument(writer);

        // Initialize document
        Document document = new Document(pdf, PageSize.A4.rotate());
        document.setMargins(20, 20, 20, 20);

        PdfFont font = PdfFontFactory.createFont(FontConstants.HELVETICA);
        PdfFont bold = PdfFontFactory.createFont(FontConstants.HELVETICA_BOLD);
        Table table = new Table(new float[]{4, 1, 3, 4, 3, 3, 1});
        //table.setWidthPercent(100);

        process(table,null, bold, true);
        for(Employee e : employees){
            process(table,e,font,false);
        }
        document.add(table);

        //Close document
        document.close();
    }

    public void process(Table table,Employee employee, PdfFont font, boolean isHeader) {

            if (isHeader) {
                table.addHeaderCell(new Cell().add(new Paragraph("Department name").setFont(font)));
                table.addHeaderCell(new Cell().add(new Paragraph("Emp no").setFont(font)));
                table.addHeaderCell(new Cell().add(new Paragraph("First Name").setFont(font)));
                table.addHeaderCell(new Cell().add(new Paragraph("Last Name").setFont(font)));
                table.addHeaderCell(new Cell().add(new Paragraph("Birth Date").setFont(font)));
                table.addHeaderCell(new Cell().add(new Paragraph("Hire Date").setFont(font)));
                table.addHeaderCell(new Cell().add(new Paragraph("Gender").setFont(font)));
            } else {
                table.addCell(new Cell().add(new Paragraph(employee.getDept_name()).setFont(font)));
                table.addCell(new Cell().add(new Paragraph(""+employee.getEmp_no()).setFont(font)));
                table.addCell(new Cell().add(new Paragraph(employee.getFirst_name()).setFont(font)));
                table.addCell(new Cell().add(new Paragraph(employee.getLast_name()).setFont(font)));
                table.addCell(new Cell().add(new Paragraph(""+employee.getBirth_date()).setFont(font)));
                table.addCell(new Cell().add(new Paragraph(""+employee.getHire_date()).setFont(font)));
                table.addCell(new Cell().add(new Paragraph(""+employee.getGender()).setFont(font)));


            }

    }
}
