package sample;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author niluxer
 */
public class UserDAO {


    /*public ObservableList<Users> fetchAll() {
        ObservableList<Users> employees = FXCollections.observableArrayList();
        try {
            String query = "SELECT * FROM employees limit 1000";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            Users p = null;
            while(rs.next()) {
                p = new Users(
                        rs.getInt("emp_no"), rs.getDate("birth_date"),
                        rs.getString("first_name"), rs.getString("last_name"),
                        rs.getString("gender").charAt(0), rs.getDate("hire_date")
                    );
                employees.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return employees;
    }*/

    Connection conn;
    public UserDAO(Connection conn)
    {
        this.conn = conn;
    }

    /*public List<Users> findAll() {
        List<Users> employees = new ArrayList<Employee>();
        try {
            String query = "SELECT * FROM employees limit 10";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            Users p = null;
            while(rs.next()) {
                p = new Users(
                        rs.getInt("emp_no"), rs.getDate("birth_date"),
                        rs.getString("first_name"), rs.getString("last_name"),
                        rs.getString("gender").charAt(0), rs.getDate("hire_date")
                );
                employees.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return employees;
    }*/

    public Users fetch(String no_emp) {
        ResultSet rs = null;
        Users e = null;
        try {
            String query = "SELECT * FROM users where id = '" + no_emp + "'";
            Statement st = conn.createStatement();
            rs = st.executeQuery(query);
            e = new Users(
                    rs.getInt("id"), rs.getString("username"),
                    rs.getString("password"), rs.getInt("emp_no")
                    );
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return e;
    }

    public boolean validUser(String username,String password) {
        ResultSet rs = null;
        Users e = null;
        int total=0;
        try {
            String query = "SELECT count(*) as total FROM user where username = '" + username + "'" +
                    "and password= md5('"+ password+"')";

            Statement st = conn.createStatement();
            rs = st.executeQuery(query);
            rs.next();
            total=rs.getInt("total");

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return (total>=1)?true:false;
    }
    
    /*public Boolean delete(int no_employee) {
        try {
            String query = "delete from employees where emp_no = ?";
            PreparedStatement st = conn.prepareStatement(query);
            st.setInt(1, no_employee);
            st.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }*/
    
    /*public Boolean insert(Employee employee) {
        try {
            String query = "insert into employees "
                    + " (emp_no, birth_date, first_name, last_name, gender, hire_date)"
                    + " values (?, ?, ?, ?, ?, ?)";
            PreparedStatement st =  conn.prepareStatement(query);
            st.setInt(   1, employee.getEmp_no());
            st.setDate(  2, employee.getBirth_date());
            st.setString(3, employee.getFirst_name());
            st.setString(4, employee.getLast_name());
            st.setString(5, String.valueOf(employee.getGender()));
            st.setDate(  6, employee.getHire_date());
            st.execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        
        return false;
    }   */

    /*public Boolean update(Employee employee) {
        try {
            String query = "update employees "
                    + " set birth_date = ?, first_name = ?, last_name = ?, gender = ?, hire_date = ?"
                    + " where emp_no=?";
            PreparedStatement st =  conn.prepareStatement(query);

            st.setDate(  1, employee.getBirth_date());
            st.setString(2, employee.getFirst_name());
            st.setString(3, employee.getLast_name());
            st.setString(4, String.valueOf(employee.getGender()));
            st.setDate(  5, employee.getHire_date());
            st.setInt(   6, employee.getEmp_no());
            st.execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        return false;
    }*/

}
