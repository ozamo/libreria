package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepEmpDAO {

    public DepEmpDAO(Connection conn)
    {
        this.conn = conn;
    }

    Connection conn;

    public  ObservableList<DepEmp> LLenadoTabla() {

        ObservableList<DepEmp> ObsListDepartamentos = FXCollections.observableArrayList();
        try {
            String query = "SELECT * FROM dept_emp";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            DepEmp p = null;
            while (rs.next()) {
                p = new DepEmp(
                        rs.getString("dept_no"),
                        rs.getInt("emp_no"),
                        rs.getDate("from_date"),
                        rs.getDate("to_date")
                );
                ObsListDepartamentos.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return ObsListDepartamentos;

    }

    public Boolean borrar(int no_employee) {
        try {
            String query = "delete from dept_emp where emp_no = ?";
            PreparedStatement st = conn.prepareStatement(query);
            st.setInt(1, no_employee);
            st.execute();
            System.out.println("Registro Borrado");
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }

    public Boolean insert(DepEmp employee) {
        try {
            String query = "insert into dept_emp "
                    + " (dept_no, emp_no,"
                    + " from_date, to_date)"
                    + " values (?, ?, ?, ?)";
            PreparedStatement st =  conn.prepareStatement(query);
            st.setString(   1, employee.getDept_no());
            st.setInt(  2, employee.getEmp_no());
            st.setDate(  3, employee.getFrom_date());
            st.setDate(  4, employee.getTo_date());
            st.execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        return false;
    }


}
