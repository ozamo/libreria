package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    @FXML
    TextField Username;
    @FXML
    Button btnCancel,btnAccept;
    @FXML
    PasswordField Password;




    public void validateCredentials(){
        Alert alert=new Alert(Alert.AlertType.INFORMATION);
        UserDAO user=new UserDAO(MySQL.getConnection());

        showStage();
        ((Stage)(btnAccept.getScene().getWindow())).hide();
        //((Stage)(btnAccept.getScene().getWindow())).hide();
        /*
        if(user.validUser(Username.getText(),Password.getText())){
            //Alert alert=new Alert(Alert.AlertType.INFORMATION);
            //alert.setContentText("Correct");
            showStage();
            ((Stage)(btnAccept.getScene().getWindow())).hide();
        }
        else{
            alert.setContentText("Incorrect");
            alert.show();

        }
        //alert.show();*/
    }

    public void showStage(){
        try{
            Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
            Stage stage=new Stage();
            stage.setTitle("");
            Scene scene=new Scene(root);
            scene.getStylesheets().add("org/kordamp/bootstrapfx/bootstrapfx.css");
            stage.setScene(scene);
            stage.setMaximized(false);
            stage.show();

        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Username.setText("admin");
        Password.setText("12345");
        btnAccept.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                validateCredentials();
            }
        });
    }
}
