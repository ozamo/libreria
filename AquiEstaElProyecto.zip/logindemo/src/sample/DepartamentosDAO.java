package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class DepartamentosDAO {

    Connection conn;

    public DepartamentosDAO(Connection conn)
    {
        this.conn = conn;
    }


    //Sentencia SQL recuperar valores de la base de datos y ponerlos en el tableView

    public ObservableList<Departamentos> LLenadoTabla()
    {
        ObservableList<Departamentos> OBListDepartamentos = FXCollections.observableArrayList();
        try {
            String query = "SELECT * FROM departments";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            Departamentos p = null;
            while(rs.next()) {
                p = new Departamentos(
                        rs.getString("dept_no"),
                        rs.getString("dept_name")
                );
                OBListDepartamentos.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return OBListDepartamentos;
    }

    //Sentencia SQL para eliminacion de registros de la base de datos

    public Boolean delete(String dept_no) {
        try {
            String query = "delete from departments where dept_no = ?";
            PreparedStatement st = conn.prepareStatement(query);
            st.setString(1,dept_no);
            st.execute();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return false;
    }


    //Sentencia SQL para

    public Boolean insert(Departamentos departamentos) {
        try {
            String query = "insert into departments "
                    + " (dept_no, dept_name)"
                    + " values (?, ?)";
            PreparedStatement st =  conn.prepareStatement(query);
            st.setString(1, departamentos.getDept_no());
            st.setString(2, departamentos.getDept_name());
            st.execute();
            System.out.println("Registro agregado");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        return false;
    }

    //Sentencia SQL para

    public Boolean update(Departamentos departamentos) {
        try {
            String query = "update departments "
                    + " set dept_name = ? where dept_no=?";
            PreparedStatement st =  conn.prepareStatement(query);

            st.setString(1, departamentos.getDept_name());
            st.setString(2, departamentos.getDept_no());
            st.execute();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }

        return false;
    }

    //Sentencia SQL para


}
