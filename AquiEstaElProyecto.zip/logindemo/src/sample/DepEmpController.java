package sample;


import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.Optional;
import java.util.ResourceBundle;

public class DepEmpController implements Initializable {

    //Variables de Controles
    @FXML
    Button btnGuardar, btnBorrar, btnNuevo, btnBack;
    @FXML
    TextField TxtNumero, TxtNumPersona;
    @FXML
    DatePicker Date1, Date2;
    @FXML
    TableView TablaDepEmp;

    DepEmpDAO depEmpDAO = new DepEmpDAO(MySQL.getConnection());


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        //creacion de la tabla

        TableColumn col1 = new TableColumn("Numero Departamento");
        TableColumn col2 = new TableColumn("Numero Empleado");
        TableColumn col3 = new TableColumn("Desde Fecha");
        TableColumn col4 = new TableColumn("Hasta Fecha");

        col1.setCellValueFactory(new PropertyValueFactory<>("dept_no"));//relacionamos la columna de la conexion
        col2.setCellValueFactory(new PropertyValueFactory<>("emp_no"));
        col3.setCellValueFactory(new PropertyValueFactory<>("from_date"));
        col4.setCellValueFactory(new PropertyValueFactory<>("to_date"));

        TablaDepEmp.getColumns().addAll(col1, col2, col3, col4);

        ObservableList<DepEmp> List = depEmpDAO.LLenadoTabla();
        TablaDepEmp.setItems(List);

        btnBack.setOnAction(CambioMain);
        btnNuevo.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                LimpiarFormulario();


            }
        });
        btnBorrar.setOnAction(Borrar);
        btnGuardar.setOnAction(insertar);


        TablaDepEmp.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(event.getClickCount()==2) {
                    DepEmp departamentos = (DepEmp) TablaDepEmp.getSelectionModel().getSelectedItem();

                    TxtNumPersona.setText(String.valueOf(departamentos.getEmp_no()));
                    TxtNumero.setText(departamentos.getDept_no());
                }
            }
        });


    }

    /***********************************************************************************************************************
     Aqui van los Metodos de los botones
     ***********************************************************************************************************************/


    public void LimpiarFormulario() {
        TxtNumero.setText("");
        TxtNumPersona.setText("");
        Date1.setValue(null);
        Date2.setValue(null);
    }

    private void ActualizarLista() {
        TablaDepEmp.getItems().clear();
        TablaDepEmp.setItems(depEmpDAO.LLenadoTabla());
    }

    private void InsertarDeptEmp(){
        DepEmp departamentos=new DepEmp(
                TxtNumero.getText(),
                Integer.valueOf(TxtNumPersona.getText()),
                Date.valueOf(Date1.getValue()),
                Date.valueOf(Date2.getValue())
        );
        if(depEmpDAO.insert(departamentos)){
            ActualizarLista();
            LimpiarFormulario();
        }
    }


//___ Eventos de los Botones ___________________________________________________________________________________________

    EventHandler<ActionEvent> Borrar = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("DELETE Confirmation");
            alert.setContentText("Are you sure you want to DELETE this departament?");
            Optional<ButtonType> result = alert.showAndWait();
            if(result.get()==ButtonType.OK) {
                DepEmp departamentos = (DepEmp) TablaDepEmp.getSelectionModel().getSelectedItem();
                depEmpDAO.borrar(departamentos.getEmp_no());
                LimpiarFormulario();
                ActualizarLista();
            }
            else{
                alert.close();
            }
        }
    };

    EventHandler<ActionEvent> insertar = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            InsertarDeptEmp();
        }
    };





//___ Cambio de Stage a Main ___________________________________________________________________________________________

    EventHandler<ActionEvent> CambioMain = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            try{
                Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
                Stage stage=new Stage();
                stage.setTitle("Menu Principal");
                Scene scene=new Scene(root);
                scene.getStylesheets().add("org/kordamp/bootstrapfx/bootstrapfx.css");
                stage.setScene(scene);
                stage.setMaximized(false);
                stage.show();
                ((Stage)(btnBack.getScene().getWindow())).hide();

            }
            catch (IOException e){
                System.out.println(e.getMessage());
            }

        }
    };
//______________________________________________________________________________________________________________________


}
