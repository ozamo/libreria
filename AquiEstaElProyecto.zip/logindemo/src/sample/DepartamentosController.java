package sample;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class DepartamentosController implements Initializable {

    @FXML
    TableView<Departamentos> TablaDepartamento;
    @FXML
    Button btnAgregar, btnActualizar, btnBorrar, btnBack;
    @FXML
    TextField TxtNombre, TxtNumero;

    DepartamentosDAO DepartamentosDAO=new DepartamentosDAO(MySQL.getConnection());


    // Variables Globales
    private boolean insertMode=false;
    private boolean updateMode=false;
    private String txt1, txt2;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        //creacion de la tabla

        TableColumn col1=new TableColumn("Numero Departamento");
        TableColumn col2=new TableColumn("Nombre Departamento");
        col1.setCellValueFactory(new PropertyValueFactory<>("dept_no"));//relacionamos la columna de la conexion
        col2.setCellValueFactory(new PropertyValueFactory<>("dept_name"));

        TablaDepartamento.getColumns().addAll(col1,col2);

        ObservableList<Departamentos> employeeList=DepartamentosDAO.LLenadoTabla();
        TablaDepartamento.setItems(employeeList);


        // Accion al dar clic en la tabla

        TablaDepartamento.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(event.getClickCount()==2) {
                    updateMode=true;
                    insertMode=false;
                    Departamentos departamentos = TablaDepartamento.getSelectionModel().getSelectedItem();

                    TxtNombre.setText(String.valueOf(departamentos.getDept_name()));
                    TxtNumero.setText(departamentos.getDept_no());
                }
            }
        });


        //Botones con las funciones a ejecutar


        btnAgregar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                LimpiarFormulario();
                insertMode=true;
                updateMode=false;
            }
        });    // Boton para Limpiar el formulario

        btnActualizar.setOnAction(AgregarEmpleado);                       // Boton para guardar el valor

        btnBorrar.setOnAction(DeleteDepartamentos);

        btnBack.setOnAction(CambioMain);

    }

/***********************************************************************************************************************
    Aqui van los eventos de los botones
***********************************************************************************************************************/
    //Accion asigna valor para agregar o actualizar registro

    EventHandler<ActionEvent> AgregarEmpleado= new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            if (insertMode) {
                InsertarDepartamento();
            } else if (updateMode) {
                ActualizarDepartamento();
            }
        }
    };


    // Accion de borrado de registro

    EventHandler<ActionEvent> DeleteDepartamentos=new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("DELETE Confirmation");
            alert.setContentText("Are you sure you want to DELETE this departament?");
            Optional<ButtonType> result = alert.showAndWait();
            if(result.get()==ButtonType.OK) {
                Departamentos departamentos = TablaDepartamento.getSelectionModel().getSelectedItem();
                DepartamentosDAO.delete(departamentos.getDept_no());
                LimpiarFormulario();
                ActualizarLista();
            }
            else{
                alert.close();
            }
        }
    };





/***********************************************************************************************************************
            Aqui van los Metodos de los botones

***********************************************************************************************************************/

    //Metodo de Limpiado de Formulario

    public void LimpiarFormulario() {
        TxtNombre.setText("");
        TxtNumero.setText("");
    }


    private void ActualizarLista(){
        TablaDepartamento.getItems().clear();
        TablaDepartamento.setItems(DepartamentosDAO.LLenadoTabla());
    }


    private void InsertarDepartamento(){
            Departamentos departamentos=new Departamentos(
                    TxtNumero.getText(),
                    TxtNombre.getText()
            );
            if(DepartamentosDAO.insert(departamentos)){
                ActualizarLista();
                LimpiarFormulario();
            }
        }


    private void ActualizarDepartamento(){
        Departamentos departamentos=new Departamentos(
                TxtNumero.getText(),
                TxtNombre.getText()
        );
        if(DepartamentosDAO.update(departamentos)){
            ActualizarLista();
            LimpiarFormulario();
        }
    }

//___ Cambio de Stage a Main ___________________________________________________________________________________________

    EventHandler<ActionEvent> CambioMain = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            try{
                Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
                Stage stage=new Stage();
                stage.setTitle("Menu Principal");
                Scene scene=new Scene(root);
                scene.getStylesheets().add("org/kordamp/bootstrapfx/bootstrapfx.css");
                stage.setScene(scene);
                stage.setMaximized(false);
                stage.show();
                ((Stage)(btnBack.getScene().getWindow())).hide();

            }
            catch (IOException e){
                System.out.println(e.getMessage());
            }

        }
    };
//______________________________________________________________________________________________________________________
}
