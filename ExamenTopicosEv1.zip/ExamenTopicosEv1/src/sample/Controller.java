package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Date;

public class Controller  implements Initializable {
    @FXML
    MenuItem apagar;
    @FXML
    MenuItem user;
    @Override
    public void initialize(URL location, ResourceBundle resources)
    {
        apagar.setOnAction(eventSalir);
        user.setOnAction(eventUsuario);
    }
    EventHandler<ActionEvent> eventSalir = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event)
        {

            Alert salir= new Alert(Alert.AlertType.CONFIRMATION);
            salir.setTitle("Confirmación");
            salir.setContentText("¿Desea Cerrar?");
            ButtonType one = new ButtonType("Si");
            ButtonType Cancel = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
            salir.getButtonTypes().setAll(one, Cancel);
            Optional<ButtonType> result = salir.showAndWait();
            if (result.get() == one){
                System.exit(0);
            } else {
            }

        }

    };
    EventHandler<ActionEvent> eventUsuario=new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            Date date =new Date();
            DateFormat hourdateformat =new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
            Alert user= new Alert(Alert.AlertType.INFORMATION);
            user.setTitle("Informacion Personal");
            user.setContentText("Pc: Oscar");
            user.setContentText("Usuario: Oscar Zamora Moya "+ "\n Hora y Fecha "+hourdateformat.format(date));
            user.show();
        }
    };

}
