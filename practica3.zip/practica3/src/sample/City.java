package sample;

public class City {
    private int id;
    private String name, countryC, district,countryName,continent,language,countryCode;
    private float surfaceArea,lifeExpectancy,GNP;
    private int population;
    public City(String district , int popu) {
        this.district=district;
        this.population=popu;
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public float getSurfaceArea() {
        return surfaceArea;
    }

    public void setSurfaceArea(float surfaceArea) {
        this.surfaceArea = surfaceArea;
    }

    public float getLifeExpectancy() {
        return lifeExpectancy;
    }

    public void setLifeExpecting(float lifeExpectancy) {
        this.lifeExpectancy = lifeExpectancy;
    }

    public float getGNP() {
        return GNP;
    }

    public void setGNP(float GNP) {
        this.GNP = GNP;
    }

    public City(String name, String continent, float surfaceArea, int population, float lifeExpectancy, float GNP, String language) {
this.name=name;
this.continent=continent;
this.surfaceArea=surfaceArea;
this.population=population;
this.lifeExpectancy=lifeExpectancy;
this.GNP=GNP;
this.language=language;

    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryname) {
        this.countryName = countryName;
    }

    public City(int id, String name, String countryCo, String district, int population,String countryName) {
        this.id = id;
        this.name = name;
        this.countryC = countryC;
        this.district = district;
        this.population = population;
        this.countryName = countryName;

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountryC() {
        return countryC;
    }

    public void setCountryC(String countryC) {
        this.countryC = countryC;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        population = population;
    }
}
