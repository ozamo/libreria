package sample;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import sun.plugin2.message.Message;


import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class MainController implements Initializable {
    @FXML
    Button colinfo, top, exit, todo, mexico, diez;
    public static final String DEST5 = "results/chapter01/cities.pdf";
    public static final String DEST6 = "results/chapter01/cities2.pdf";
    public static final String DEST7 = "results/chapter01/cities3.pdf";

    @FXML
    TableView<City> tableCities;
    CityDAO cityDAO = new CityDAO(MySQL.getConnection());
    Country country;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        todo.setOnAction(handlerButtons);
        mexico.setOnAction(handlerButtons);
        diez.setOnAction(handlerButtons);


        TableColumn column1 = new TableColumn("Id");
        TableColumn column2 = new TableColumn("Name");
        TableColumn column3 = new TableColumn("Country Code");
        TableColumn column4 = new TableColumn("District");
        TableColumn column5 = new TableColumn("Population");
        TableColumn column6 = new TableColumn("Country Name");

        column1.setCellValueFactory(new PropertyValueFactory<>("id"));
        column2.setCellValueFactory(new PropertyValueFactory<>("name"));
        column3.setCellValueFactory(new PropertyValueFactory<>("countryC"));
        column4.setCellValueFactory(new PropertyValueFactory<>("district"));
        column5.setCellValueFactory(new PropertyValueFactory<>("population"));
        column6.setCellValueFactory(new PropertyValueFactory<>("countryName"));

        tableCities.getColumns().addAll(column1, column2, column3, column4, column5, column6);

        ObservableList<City> cities1List = cityDAO.fetchAll();
        tableCities.setItems(cities1List);
        colinfo.setOnAction(handlerinfo);
        exit.setOnAction(salir);
        top.setOnAction(topAction);

    }

    EventHandler<ActionEvent> salir = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            System.exit(0);
        }
    };
    EventHandler<ActionEvent> topAction = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            infotop();
        }

    };
    EventHandler<ActionEvent> handlerinfo = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            info();
        }

    };

    public void info() {

        City city = tableCities.getSelectionModel().getSelectedItem();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        Country country = cityDAO.fetch(city.getCountryC());
        alert.setContentText("Code: " + country.getCode() +
                "\nName: " + country.getName() +
                "\nContinent: " + country.getContinent() + "\nRegion: " + country.getRegion() + "\nSurface Area: " + country.getSurface() + "\nPopulation: " + country.getPopulation() +
                "\nLife Expectancy: " + country.getLifeexpect() + "\nCapital: " + country.getCapital() +
                "\nHead Of State: " + country.getHead()
        );
        alert.show();

    }

    public void infotop() {

        ObservableList<City> listcity = cityDAO.city();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        tableCities.setItems(listcity);


    }

    EventHandler<ActionEvent> handlerButtons = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            if (event.getSource() == mexico) {
                File file = new File(DEST5);
                file.getParentFile().mkdirs();
                CityDAO employeeDAO = new CityDAO(MySQL.getConnection());

                try {
                    new Cities().createPdf(DEST5, employeeDAO.mex());

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }



            if (event.getSource() == todo) {
                File file = new File(DEST6);
                file.getParentFile().mkdirs();
                CityDAO employeeDAO = new CityDAO(MySQL.getConnection());

                try {
                    new Cities2().createPdf(DEST6, employeeDAO.todos());

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }


            if (event.getSource() == diez) {
                File file = new File(DEST7);
                file.getParentFile().mkdirs();
                CityDAO employeeDAO = new CityDAO(MySQL.getConnection());

                try {
                    new Cities3().createPdf(DEST7, employeeDAO.diez());

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    };



}
