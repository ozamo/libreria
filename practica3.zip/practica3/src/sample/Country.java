package sample;

public class Country {
    String code, name, continent, region;
    float surface;
    int population;
    float lifeexpect;
    String head;
    int capital;

    public Country(String code, String name, String continent, String region, float surface, int population, float lifeexpect, String head, int capital) {
        this.code = code;
        this.name = name;
        this.continent = continent;
        this.region = region;
        this.surface = surface;
        this.population = population;
        this.lifeexpect = lifeexpect;
        this.head = head;
        this.capital = capital;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public float getSurface() {
        return surface;
    }

    public void setSurface(float surfacearea) {
        this.surface = surfacearea;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public float getLifeexpect() {
        return lifeexpect;
    }

    public void setLifeexpect(float lifeexpectancy) {
        this.lifeexpect= lifeexpectancy;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public int getCapital() {
        return capital;
    }

    public void setCapital(int capital) {
        this.capital = capital;
    }
}