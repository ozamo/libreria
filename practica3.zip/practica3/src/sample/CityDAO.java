package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author niluxer
 */
public class CityDAO {
    public Country fetch(String code) {

        Country c = null;
        try {
            String query = "SELECT code, c.name, continent, region,surfacearea , c.population, lifeexpectancy, headofstate, capital FROM country c where code = '" + code + "'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while(rs.next()) {
                c = new Country(
                        rs.getString("code"),
                        rs.getString("c.name"),
                        rs.getString("continent"),
                        rs.getString("region"),
                        rs.getFloat("surfacearea"),
                        rs.getInt("c.population"),
                        rs.getFloat("lifeexpectancy"),
                        rs.getString("headofstate"),
                        rs.getInt("capital")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return c;
    }
    public ObservableList<City> city( ) {

        City c = null;
        ObservableList<City> city = FXCollections.observableArrayList();
        try {
            String query = "SELECT id, ci.name, ci.countryCode, ci.district, ci.population,co.name  FROM city ci, country co where ci.CountryCode=co.Code Order by population desc limit 5";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                c = new City(
                        rs.getInt("id"), rs.getString("name"),
                        rs.getString("countrycode"), rs.getString("district"),
                        rs.getInt("population"),
                        rs.getString("co.name")
                );
                city.add(c);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return city;
    }
    public ObservableList<City> fetchAll() {
        ObservableList<City> city = FXCollections.observableArrayList();
        try {
            String query = "SELECT id, ci.name, ci.countryCode, ci.district, ci.population,co.name  FROM city ci, country co where ci.CountryCode=co.Code ";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            City p = null;
            while (rs.next()) {
                p = new City(
                        rs.getInt("id"), rs.getString("name"),
                        rs.getString("countrycode"), rs.getString("district"),
                        rs.getInt("population"),
                        rs.getString("co.name")
                );
                city.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return city;
    }

    Connection conn;

    public CityDAO(Connection conn) {
        this.conn = conn;
    }




    public List<City> mex() {
        List<City> city = new ArrayList<City>();
        try {
            String query =  "select city.District,SUM(city.Population) popu FROM city join country c on city.CountryCode = c.Code\n" +
                    "            where c.Code='MEX'\n" +
                    "            group by city.District\n" +
                    "            order by  city.District asc;";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            City p = null;
            while(rs.next()) {
                p = new City(
                        rs.getString("city.District"), rs.getInt("popu")
                );
                city.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return city;
    }

    public List<City> diez() {
        List<City> city = new ArrayList<City>();
        try {
            String query =  "select c.Name,co.Continent,co.SurfaceArea,c.Population,co.LifeExpectancy,co.GNP,co.Name from city c join country co on c.CountryCode = co.Code where co.Continent=\"North America\" or co.Continent=\"South America\" order by c.Population DESC limit 10;";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            City p = null;
            while(rs.next()) {
                p = new City(
                        rs.getString("c.Name"), rs.getString("co.Continent"),
                        rs.getFloat("co.SurfaceArea"),
                        rs.getInt("c.Population"),
                        rs.getFloat("co.LifeExpectancy"),
                        rs.getFloat("co.GNP"),
                        rs.getString("co.Name")
                );
                city.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return city;
    }

    public List<City> todos() {
        List<City> city = new ArrayList<City>();
        try {
            String query =  "select country.Name,country.Continent,country.SurfaceArea,country.Population,country.LifeExpectancy,country.GNP,countrylanguage.Language\n" +
                    "FROM country,countrylanguage;";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            City p = null;
            while(rs.next()) {
                p = new City(
                        rs.getString("country.Name"), rs.getString("country.Continent"),
                        rs.getFloat("country.SurfaceArea"),
                        rs.getInt("country.Population"),
                        rs.getFloat("country.LifeExpectancy"),
                        rs.getFloat("country.GNP"),
                        rs.getString("countrylanguage.Language")

                );
                city.add(p);
            }
            rs.close();
            st.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println("Error al recuperar información...");
        }
        return city;
    }
}
