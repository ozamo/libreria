package sample;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javax.swing.*;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class Controller implements Initializable
{
    @FXML
    MenuItem salir;
    @Override
    public void initialize(URL location, ResourceBundle resources)
    {
        salir.setOnAction(eventSalir);
    }
    EventHandler<ActionEvent> eventSalir = new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event)
        {
            Alert salir= new Alert(Alert.AlertType.CONFIRMATION);
            salir.setTitle("Confirmación");
            salir.setContentText("¿Desea Cerrar?");
            ButtonType one = new ButtonType("Si");
            ButtonType Cancel = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
            salir.getButtonTypes().setAll(one, Cancel);
            Optional<ButtonType> result = salir.showAndWait();
            if (result.get() == one){
                System.exit(0);
            } else {
            }

        }

    };



}